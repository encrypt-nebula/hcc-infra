import json
import boto3
import os
from datetime import datetime

s3 = boto3.client('s3')
sqs = boto3.client('sqs')

# Environment variables (set by Terraform)
try:
    PAGES_BUCKET = os.environ['PAGES_BUCKET']
    PAGE_QUEUE_URL = os.environ['PAGE_QUEUE_URL']
    RAW_DOCS_BUCKET = os.environ['RAW_DOCS_BUCKET']
except KeyError:
    # Set defaults for local testing if needed, or rely on them being set in Lambda
    PAGES_BUCKET = "test-pages-bucket"
    PAGE_QUEUE_URL = "test-queue-url"
    RAW_DOCS_BUCKET = "test-raw-docs-bucket"

def lambda_handler(event, context):
    """
    Triggered by S3 upload or direct invocation via Function URL
    Determines project type and processes file accordingly
    """
    
    # Handle Function URL invocation (manual upload)
    if 'body' in event:
        return handle_function_url(event, context)
    
    # Handle S3 Event trigger (automated)
    if 'Records' in event and event['Records'][0].get('eventSource') == 'aws:s3':
        return handle_s3_event(event, context)
    
    return {
        'statusCode': 400,
        'body': json.dumps({'error': 'Invalid event type'})
    }

def handle_function_url(event, context):
    """
    Handle direct HTTP POST to Lambda Function URL
    Expects: { "project_id": 1, "project_type": "PROSPECTIVE", "file_key": "..." }
    """
    try:
        if isinstance(event['body'], str):
            body = json.loads(event['body'])
        else:
            body = event['body']
            
        project_id = body.get('project_id')
        project_type = body.get('project_type')  # "PROSPECTIVE" or "RETROSPECTIVE"
        file_key = body.get('file_key')
        
        if not all([project_id, project_type, file_key]):
             return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Missing required fields: project_id, project_type, file_key'})
            }

        # Process the file
        result = process_file(file_key, project_id, project_type)
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps(result)
        }
    except Exception as e:
        print(f"Error in handle_function_url: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

def handle_s3_event(event, context):
    """
    Handle S3 upload event
    File path structure: uploads/{project_id}/{project_type}/{filename}
    """
    results = []
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']
        
        # Parse project info from file path
        # Expected: uploads/123/PROSPECTIVE/provider_chart.pdf
        # OR: uploads/456/RETROSPECTIVE/insurance_claims.pdf
        try:
            parts = key.split('/')
            if len(parts) < 4:
                print(f"Invalid file path format: {key}")
                continue
            
            # parts[0] is uploads
            project_id = parts[1]
            project_type = parts[2]  # PROSPECTIVE or RETROSPECTIVE
            # filename = parts[3] # Not used directly but good to know
            
            # Process the file
            result = process_file(key, project_id, project_type)
            results.append(result)
            print(f"Processed: {result}")
        except Exception as e:
             print(f"Error processing record {key}: {str(e)}")

    return {
        'statusCode': 200,
        'body': json.dumps({'message': 'Files processed', 'results': results})
    }

def process_file(file_key, project_id, project_type):
    """
    Process file based on project type
    - PROSPECTIVE: Provider/Doctor files (medical charts)
    - RETROSPECTIVE: Insurance files (claims data)
    """
    
    print(f"Processing {project_type} file: {file_key}")
    
    try:
        # Get file metadata
        # Note: In a real S3 event, the size is often in the event, but head_object is safer
        s3_response = s3.head_object(Bucket=RAW_DOCS_BUCKET, Key=file_key)
        file_size = s3_response['ContentLength']
        
        # Determine file type
        file_extension = file_key.lower().split('.')[-1]
        
        if file_extension == 'pdf':
            total_pages = estimate_pdf_pages(file_size)
        elif file_extension in ['jpg', 'jpeg', 'png']:
            total_pages = 1
        else:
             print(f"Warning: Unsupported file type extension {file_extension}. Defaulting to 1 page.")
             total_pages = 1
        
        # Create page processing tasks
        # Send in batches if possible, but for now simple loop
        for page_num in range(1, total_pages + 1):
            message = {
                'file_key': file_key,
                'project_id': project_id,
                'project_type': project_type,
                'page_num': page_num,
                'total_pages': total_pages,
                'timestamp': datetime.utcnow().isoformat()
            }
            
            # Send to page processing queue
            sqs.send_message(
                QueueUrl=PAGE_QUEUE_URL,
                MessageBody=json.dumps(message)
            )
        
        return {
            'file_key': file_key,
            'project_id': project_id,
            'project_type': project_type,
            'total_pages': total_pages,
            'status': 'queued'
        }
    except Exception as e:
        print(f"Error in process_file: {str(e)}")
        raise e

def estimate_pdf_pages(file_size_bytes):
    """
    Rough estimate: 50KB per page average
    This is just for demo - real implementation would parse PDF
    """
    avg_page_size = 50000  # 50KB
    estimated_pages = max(1, file_size_bytes // avg_page_size)
    return min(estimated_pages, 300)  # Cap at 300 pages

# For local testing
if __name__ == '__main__':
    # Test PROSPECTIVE project
    # Mocking environment variables for local run if they aren't set
    if 'PAGES_BUCKET' not in os.environ:
         os.environ['PAGES_BUCKET'] = 'mock-pages-bucket'
    if 'PAGE_QUEUE_URL' not in os.environ:
         os.environ['PAGE_QUEUE_URL'] = 'mock-queue-url'
    if 'RAW_DOCS_BUCKET' not in os.environ:
         os.environ['RAW_DOCS_BUCKET'] = 'mock-raw-docs-bucket'
         
    test_event = {
        'body': json.dumps({
            'project_id': '1',
            'project_type': 'PROSPECTIVE',
            'file_key': 'uploads/1/PROSPECTIVE/provider_chart.pdf'
        })
    }
    # This will fail locally without AWS creds/connection unless mocked, but correct structure.
    print("Local test execution (mocked):")
    # print(lambda_handler(test_event, None)) 
